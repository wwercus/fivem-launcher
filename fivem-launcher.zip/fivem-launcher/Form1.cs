﻿using DiscordRPC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.IO;


namespace FiveM_Launcher
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            Class1.InitializeRPC();
            Class1.rpctimestamp = Timestamps.Now;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.MaximumSize = this.Size;
            this.MinimumSize = this.Size;


        }

        private void siticoneGradientButton1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start($"https://discord.gg/twojdiscord");
        }

        private void siticoneGradientButton1_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start($"fivem://connect/11.11.11.11:30120");
        }

        private void siticoneGradientButton2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start($"https://strona.pl");
        }
    }
}

