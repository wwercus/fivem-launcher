﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiscordRPC;

namespace FiveM_Launcher
{
    internal class Class1
    {
		public static DiscordRpcClient client;
		public static Timestamps rpctimestamp { get; set; }
		private static RichPresence presence;
		public static void InitializeRPC()
		{
			client = new DiscordRpcClient("947751796506501181");
			client.Initialize();
			Button[] buttons = { new Button() { Label = "Discord", Url = "https://discord.gg/twojdiscord" } };

			presence = new RichPresence()
			{
				Details = "",
				State = "",
				Timestamps = rpctimestamp,
				Buttons = buttons,

				Assets = new Assets()
				{
					LargeImageKey = "testrp",
					LargeImageText = "FiveM-Launcher - Free Download",
					SmallImageKey = "testrp",
					SmallImageText = "github.com/wwercus/fivem-launcher"
				}
			};
			SetState("");
		}
		public static void SetState(string state, bool watching = false)
		{
			if (watching)
				state = "Looking at " + state;

			presence.State = state;
			client.SetPresence(presence);
		}




	}
}
